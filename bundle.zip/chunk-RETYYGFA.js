var o="1.1.2";export{o as a};
