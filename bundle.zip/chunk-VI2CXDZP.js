var o="1.1.1";export{o as a};
