var o="1.1.5";export{o as a};
